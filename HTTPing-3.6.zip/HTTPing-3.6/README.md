httping
=======

Ping with HTTP requests, see http://www.vanheusden.com/httping/
