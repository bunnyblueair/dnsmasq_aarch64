/* taken (and adapted) from http://www.dzone.com/snippets/simple-kalman-filter-c */

void kalman_init(double ideal_value);
double kalman_do(double value);
